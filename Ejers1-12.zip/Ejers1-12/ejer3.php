<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $h1 = "Español";
        $h2 = "English";
        $es1 = "Hola";
        $es2 = "Playa";
        $es3 = "Coche";
        $es4 = "Palabra";
        $es5 = "Suelo";
        $en1 = "Hello";
        $en2 = "Beach";
        $en3 = "Car";
        $en4 = "Word";
        $en5 = "Floor";

        echo "<table border='1'>";
        echo "
            </tr>
            <th>$h1</th>
            <th>$h2</th>";
        echo "
            </tr>
            <td>$es1</td>
            <td>$en1</td>
            </tr>";
        echo "
            <td>$es2</td>
            <td>$en2</td>
            </tr>";
        echo "
            <td>$es3</td>
            <td>$en3</td>
            </tr>";
        echo "
            <td>$es4</td>
            <td>$en4</td>
            </tr>";
        echo "
            <td>$es5</td>
            <td>$en5</td>
            ";
        ?>
    </body>
</html>
