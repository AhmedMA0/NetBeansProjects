<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
            $nombre = "Ahmed Mohamed Ahmed";
            $direccion = "Avd Ejercito Español Grp. Rocio B2 P3 3ºB";
            $telefono = 665453135;
            
            echo $nombre;
            echo $direccion;
            echo $telefono;
        ?>
    </body>
</html>
