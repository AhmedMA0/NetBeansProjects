<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="ejer9_2.php" method="get">
            Radio de la base: <input type="number" name="a"><br>
            Altura del cono: <input type="number" name="b"><br>
            <input type="submit" value="Calcular">
        </form>
    </body>
</html>
