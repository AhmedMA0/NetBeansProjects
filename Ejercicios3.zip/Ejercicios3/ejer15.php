<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title></title>
  </head>
  <body>
        <form action="ejer15_1.php" method="post">

            1. Tu pareja parece estar más inquieta de lo normal sin ningún motivo
            aparente.<br>
            <input type="radio" name="r1" value="3">verdadero<br>
            <input type="radio" name="r1" value="0">falso<br>
            
            2. Ha aumentado sus gastos de vestuario.<br>
            <input type="radio" name="r2" value="3">verdadero<br>
            <input type="radio" name="r2" value="0">falso<br>
            
            3. Ha perdido el interés que mostraba anteriormente por ti.<br>
            <input type="radio" name="r3" value="3">verdadero<br>
            <input type="radio" name="r3" value="0">falso<br>
            
            4. Ahora se afeita y se asea con más frecuencia (si es hombre) o ahora se
            arregla el pelo y se asea con más frecuencia (si es mujer).<br>
            <input type="radio" name="r4" value="3">verdadero<br>
            <input type="radio" name="r4" value="0">falso<br>
            
            5. No te deja que mires la agenda de su teléfono móvil.<br>
            <input type="radio" name="r5" value="3">verdadero<br>
            <input type="radio" name="r5" value="0">falso<br>
            
            6. A veces tiene llamadas que dice no querer contestar cuando estás
            tú delante.<br>
            <input type="radio" name="r6" value="3">verdadero<br>
            <input type="radio" name="r6" value="0">falso<br>
            
            7. Últimamente se preocupa más en cuidar la línea y/o estar bronceado/a.<br>
            <input type="radio" name="r7" value="3">verdadero<br>
            <input type="radio" name="r7" value="0">falso<br>
            
            8. Muchos días viene tarde después de trabajar porque dice tener mucho
            más trabajo.<br>
            <input type="radio" name="r8" value="3">verdadero<br>
            <input type="radio" name="r8" value="0">falso<br>
            
            9. Has notado que últimamente se perfuma más.<br>
            <input type="radio" name="r9" value="3">verdadero<br>
            <input type="radio" name="r9" value="0">falso<br>
            
            10. Se confunde y te dice que ha estado en sitios donde no ha ido contigo.<br>
            <input type="radio" name="r10" value="3">verdadero<br>
            <input type="radio" name="r10" value="0">falso<br>
            <input type="submit" value="Aceptar">
        </form>
  </body>
</html>